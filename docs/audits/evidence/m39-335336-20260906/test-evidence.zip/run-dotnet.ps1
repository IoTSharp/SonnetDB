param([string[]]$Arguments, [int]$TimeoutSeconds = 240, [string]$LogName = 'build')
$ErrorActionPreference = 'Stop'
if ($PSVersionTable.PSVersion.Major -lt 7) { throw 'PowerShell 7 required' }
$start = [Diagnostics.ProcessStartInfo]::new('C:\Program Files\dotnet\dotnet.exe')
$start.UseShellExecute = $false
$start.CreateNoWindow = $true
$start.RedirectStandardOutput = $true
$start.RedirectStandardError = $true
$start.WorkingDirectory = 'D:\source\SonnetDB'
$start.Environment['DOTNET_CLI_DO_NOT_USE_MSBUILD_SERVER'] = '1'
foreach ($argument in $Arguments) { $start.ArgumentList.Add($argument) }
$process = [Diagnostics.Process]::new()
$process.StartInfo = $start
try {
    [void]$process.Start()
    $ownedStartTime = $process.StartTime
    Get-CimInstance Win32_Process -Filter "ProcessId = $($process.Id)" |
        Select-Object ProcessId, ParentProcessId, CreationDate, CommandLine |
        ConvertTo-Json -Compress | Tee-Object -FilePath (Join-Path $PSScriptRoot "$LogName-process.json")
    $stdout = $process.StandardOutput.ReadToEndAsync()
    $stderr = $process.StandardError.ReadToEndAsync()
    if (-not $process.WaitForExit($TimeoutSeconds * 1000)) { throw "dotnet timed out after $TimeoutSeconds seconds" }
    $output = $stdout.GetAwaiter().GetResult() + $stderr.GetAwaiter().GetResult()
    $output | Set-Content -LiteralPath (Join-Path $PSScriptRoot "$LogName.log")
    $output
    $result = $process.ExitCode
} finally {
    if (-not $process.HasExited -and $process.StartTime -eq $ownedStartTime) {
        $process.Kill($true)
        [void]$process.WaitForExit(10000)
    }
    $process.Dispose()
}
exit $result
