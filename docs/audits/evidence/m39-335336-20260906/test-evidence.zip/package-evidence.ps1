$ErrorActionPreference = 'Stop'
if ($PSVersionTable.PSVersion.Major -lt 7) { throw 'PowerShell 7 required' }
$timer = [Diagnostics.Stopwatch]::StartNew()
$taskRoot = 'C:\Users\mysti\AppData\Local\Temp\sonnetdb-m39-335336-20260906'
$evidenceRoot = 'D:\source\SonnetDB\docs\audits\evidence\m39-335336-20260906'
$reports = @('m39-core.trx', 'm39-sql-tables.trx', 'm39-server.trx', 'm39-crash.trx', 'm39-final-targeted.trx')
$summaries = @()
$uniqueTests = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
foreach ($reportName in $reports) {
    if ($timer.Elapsed.TotalSeconds -gt 60) { throw 'Evidence packaging timeout' }
    [xml]$report = Get-Content -LiteralPath (Join-Path $taskRoot "results\$reportName") -Raw
    $results = @($report.TestRun.Results.UnitTestResult)
    if ($results.Count -gt 2000) { throw 'Unexpected result count' }
    foreach ($result in $results) {
        if ($result.outcome -ne 'Passed') { throw "Nonpassing test: $($result.testName)" }
        [void]$uniqueTests.Add([string]$result.testName)
    }
    $summaries += [ordered]@{ report = "results/$reportName"; passed = $results.Count; failed = 0 }
}
$sourceFiles = @(git diff --name-only -- src tests) + @(
    'src/SonnetDB.Core/Routines/TriggerTransitionTables.cs',
    'tests/SonnetDB.Core.Tests/Sql/SqlTriggerAdvancedTests.cs')
$sourceFiles = @($sourceFiles | Sort-Object -Unique)
if ($sourceFiles.Count -gt 64) { throw 'Unexpected changed source count' }
$sourceHashes = @()
foreach ($relative in $sourceFiles) {
    if ($timer.Elapsed.TotalSeconds -gt 60) { throw 'Source hashing timeout' }
    $sourceHashes += [ordered]@{ path = $relative; sha256 = (Get-FileHash -LiteralPath (Join-Path 'D:\source\SonnetDB' $relative)).Hash }
}
[void](New-Item -ItemType Directory -Path $evidenceRoot -Force)
$archivePath = Join-Path $evidenceRoot 'test-evidence.zip'
if (Test-Path -LiteralPath $archivePath) { throw 'Evidence already exists' }
$files = @(Get-ChildItem -LiteralPath $taskRoot -File -Recurse -Depth 2 | Select-Object -First 65)
if ($files.Count -gt 64 -or ($files | Measure-Object Length -Sum).Sum -gt 10MB) { throw 'Unexpected task artifact size' }
$archive = [IO.Compression.ZipFile]::Open($archivePath, [IO.Compression.ZipArchiveMode]::Create)
try {
    foreach ($file in $files) {
        if ($timer.Elapsed.TotalSeconds -gt 60) { throw 'Archive creation timeout' }
        $relative = [IO.Path]::GetRelativePath($taskRoot, $file.FullName).Replace('\', '/')
        [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive, $file.FullName, $relative, [IO.Compression.CompressionLevel]::Optimal)
    }
} finally { $archive.Dispose() }
$archive = [IO.Compression.ZipFile]::OpenRead($archivePath)
try {
    foreach ($file in $files) {
        if ($timer.Elapsed.TotalSeconds -gt 60) { throw 'Archive verification timeout' }
        $relative = [IO.Path]::GetRelativePath($taskRoot, $file.FullName).Replace('\', '/')
        $stream = $archive.GetEntry($relative).Open()
        try { $archivedHash = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)) }
        finally { $stream.Dispose() }
        if ($archivedHash -ne (Get-FileHash -LiteralPath $file.FullName).Hash) { throw "Archive mismatch: $relative" }
    }
} finally { $archive.Dispose() }
$summary = [ordered]@{
    recordedAt = [DateTimeOffset]::Now.ToString('O')
    uniquePassedTests = $uniqueTests.Count
    runs = $summaries
    archive = 'test-evidence.zip'
    archiveSha256 = (Get-FileHash -LiteralPath $archivePath).Hash
    nativeAotPublishExecuted = $false
    remoteCiExecuted = $false
    sources = $sourceHashes
}
$summary | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $evidenceRoot 'validation.json')
"Archived $($files.Count) files; $($uniqueTests.Count) unique passing tests; SHA-256 verified."
