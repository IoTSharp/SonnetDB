param([string]$LogName, [int]$TimeoutSeconds = 240, [string[]]$DotnetArguments)
$ErrorActionPreference = 'Stop'
if ($PSVersionTable.PSVersion.Major -lt 7) { throw 'PowerShell 7 required' }
if ($TimeoutSeconds -lt 1 -or $TimeoutSeconds -gt 900) { throw 'Invalid timeout' }
if ($DotnetArguments.Count -gt 32) { throw 'Too many arguments' }
$logRoot = 'C:\Users\mysti\AppData\Local\Temp\sndb338-validation-20260908'
$logPath = Join-Path $logRoot ($LogName + '.log')
$start = [Diagnostics.ProcessStartInfo]::new('C:\Program Files\dotnet\dotnet.exe')
$start.WorkingDirectory = 'D:\source\SonnetDB'
$start.UseShellExecute = $false
$start.CreateNoWindow = $true
$start.RedirectStandardOutput = $true
$start.RedirectStandardError = $true
$start.Environment['DOTNET_CLI_USE_MSBUILD_SERVER'] = '0'
$argumentTimer = [Diagnostics.Stopwatch]::StartNew()
foreach ($argument in $DotnetArguments) {
    if ($argumentTimer.Elapsed.TotalSeconds -ge 5) { throw 'Argument setup timeout' }
    $start.ArgumentList.Add($argument)
}
$process = [Diagnostics.Process]::new()
$process.StartInfo = $start
$started = $false
try {
    $started = $process.Start()
    $identity = Get-CimInstance Win32_Process -Filter "ProcessId = $($process.Id)"
    $identity | Select-Object ProcessId,ParentProcessId,CreationDate,CommandLine | ConvertTo-Json -Compress
    $identity | Select-Object ProcessId,ParentProcessId,CreationDate,CommandLine | ConvertTo-Json | Set-Content ($logPath + '.process.json')
    $stdout = $process.StandardOutput.ReadToEndAsync()
    $stderr = $process.StandardError.ReadToEndAsync()
    $timer = [Diagnostics.Stopwatch]::StartNew()
    $finished = $false
    $maxPolls = [int][Math]::Ceiling($TimeoutSeconds / 5.0) + 1
    for ($poll = 0; $poll -lt $maxPolls -and $timer.Elapsed.TotalSeconds -lt $TimeoutSeconds; $poll++) {
        $remaining = [int][Math]::Max(1, ($TimeoutSeconds * 1000) - $timer.Elapsed.TotalMilliseconds)
        if ($process.WaitForExit([Math]::Min(5000, $remaining))) { $finished = $true; break }
        if (($poll + 1) % 10 -eq 0) { Write-Output "Validation still running: PID $($process.Id), $([int]$timer.Elapsed.TotalSeconds)s" }
    }
    if (-not $finished) { throw "Validation timeout after $TimeoutSeconds seconds" }
    $output = $stdout.GetAwaiter().GetResult() + $stderr.GetAwaiter().GetResult()
    $output | Set-Content -LiteralPath $logPath
    Write-Output $output
    exit $process.ExitCode
}
finally {
    if ($started -and -not $process.HasExited) {
        # The retained Process instance plus recorded creation/command/parent identifies our own tree.
        $current = Get-CimInstance Win32_Process -Filter "ProcessId = $($process.Id)"
        if ($current.CreationDate -eq $identity.CreationDate -and $current.CommandLine -eq $identity.CommandLine -and $current.ParentProcessId -eq $identity.ParentProcessId) {
            $process.Kill($true)
            [void]$process.WaitForExit(10000)
        }
    }
    $process.Dispose()
}
