param([switch]$Trial)
$ErrorActionPreference = 'Stop'
if ($PSVersionTable.PSVersion.Major -lt 7) { throw 'PowerShell 7 required' }
$taskRoot = 'C:/Users/mysti/AppData/Local/Temp/sndb338-validation-20260908'
$repository = 'D:/source/SonnetDB'
$destination = Join-Path $repository 'docs/audits/evidence/m39-338-20260908'
$timer = [Diagnostics.Stopwatch]::StartNew()
$reports = if ($Trial) { @('m39-338-crash.trx') } else {
    @('m39-338-core-complete.trx', 'm39-338-server.trx', 'm39-338-crash.trx')
}
$runs = @()
$testKeys = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
foreach ($report in $reports) {
    if ($timer.Elapsed.TotalSeconds -ge 30) { throw 'Report budget exceeded' }
    [xml]$xml = Get-Content -Raw -LiteralPath (Join-Path $taskRoot $report)
    $counters = $xml.TestRun.ResultSummary.Counters
    $results = @($xml.TestRun.Results.UnitTestResult)
    if ($results.Count -gt 10000) { throw 'Unexpected test report size' }
    if ([int]$counters.failed -ne 0 -or [int]$counters.notExecuted -ne 0) { throw "Final gate did not pass: $report" }
    foreach ($result in $results) {
        if ($timer.Elapsed.TotalSeconds -ge 30) { throw 'Test extraction budget exceeded' }
        if ($result.outcome -eq 'Passed') { [void]$testKeys.Add($report + ':' + $result.testId) }
    }
    $runs += [ordered]@{
        report = $report
        started = $xml.TestRun.Times.start
        finished = $xml.TestRun.Times.finish
        passed = [int]$counters.passed
        failed = [int]$counters.failed
        skipped = [int]$counters.notExecuted
    }
}
if ($Trial) { $runs | ConvertTo-Json -Depth 5; exit 0 }

$changed = @(& git -C $repository diff --name-only)
$untracked = @(& git -C $repository ls-files --others --exclude-standard)
$sourcePaths = @($changed + $untracked | Where-Object { $_ -match '^(src|tests)/.*\.(cs|csproj)$' } | Sort-Object -Unique)
if ($sourcePaths.Count -gt 128) { throw 'Source provenance budget exceeded' }
$sourceHashes = @()
foreach ($relative in $sourcePaths) {
    if ($timer.Elapsed.TotalSeconds -ge 60) { throw 'Source hashing timeout' }
    $sourceHashes += [ordered]@{ path = $relative; sha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $repository $relative)).Hash }
}
$assemblies = @(
    'src/SonnetDB.Core/bin/Debug/net10.0/SonnetDB.Core.dll',
    'src/SonnetDB.Core/bin/Release/net10.0/SonnetDB.Core.dll',
    'src/SonnetDB/bin/Release/net10.0/SonnetDB.dll',
    'tests/SonnetDB.Core.Tests/bin/Debug/net10.0/SonnetDB.Core.Tests.dll',
    'tests/SonnetDB.Tests/bin/Debug/net10.0/win-x64/SonnetDB.Tests.dll',
    'tests/SonnetDB.CrashTests/bin/Debug/net10.0/SonnetDB.CrashTests.dll',
    'tests/SonnetDB.CrashTests/Child/bin/Debug/net10.0/SonnetDB.CrashTests.Child.dll'
)
$binaryHashes = @()
foreach ($relative in $assemblies) {
    if ($timer.Elapsed.TotalSeconds -ge 60) { throw 'Assembly hashing timeout' }
    $file = Get-Item -LiteralPath (Join-Path $repository $relative)
    $binaryHashes += [ordered]@{ path = $relative; size = $file.Length; modifiedUtc = $file.LastWriteTimeUtc.ToString('O'); sha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $file.FullName).Hash }
}
$files = @(Get-ChildItem -LiteralPath $taskRoot -File)
if ($files.Count -gt 64) { throw 'Archive item budget exceeded' }
if ($timer.Elapsed.TotalSeconds -ge 90) { throw 'Archive preparation timeout' }
[void][IO.Directory]::CreateDirectory($destination)
$archive = Join-Path $destination 'test-evidence.zip'
Compress-Archive -LiteralPath $files.FullName -DestinationPath $archive -CompressionLevel Optimal -Force
if ($timer.Elapsed.TotalSeconds -ge 120) { throw 'Archive compression exceeded time budget' }
$manifest = [ordered]@{
    recordedAt = [DateTimeOffset]::Now.ToString('O')
    baseCommit = (& git -C $repository rev-parse HEAD)
    branch = (& git -C $repository branch --show-current)
    provenance = 'Uncommitted working tree containing pre-existing #335/#336 work plus #338; no merge, release, or remote CI claimed.'
    operatingSystem = [Runtime.InteropServices.RuntimeInformation]::OSDescription
    architecture = [Runtime.InteropServices.RuntimeInformation]::OSArchitecture.ToString()
    powerShell = $PSVersionTable.PSVersion.ToString()
    dotnetSdk = '10.0.400'
    uniquePassedTests = $testKeys.Count
    runs = $runs
    releaseAotAnalysis = 'release-aot.log; IsAotCompatible/EnableAotAnalyzer/EnableTrimAnalyzer properties recorded separately'
    nativeAotPublishExecuted = $false
    remoteCiExecuted = $false
    intermediateFailures = 'All intermediate logs retained: fixture grammar, nullable/discard compilation, concurrent-edit compilation, legacy catalog-version assertion, and an unchanged KV loopback HTTP server disposal race (ObjectDisposedException). KV recheck passed 7/7 without code changes. Only the final runs above count toward acceptance.'
    archive = 'test-evidence.zip'
    archiveSha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $archive).Hash
    sources = $sourceHashes
    assemblies = $binaryHashes
}
$manifest | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $destination 'validation.json')
$runs | ConvertTo-Json -Depth 5
Write-Output "Unique passed tests: $($testKeys.Count); archive bytes: $((Get-Item -LiteralPath $archive).Length)"
