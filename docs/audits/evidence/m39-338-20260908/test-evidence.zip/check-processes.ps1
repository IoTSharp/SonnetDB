param([switch]$Trial)
$ErrorActionPreference = 'Stop'
if ($PSVersionTable.PSVersion.Major -lt 7) { throw 'PowerShell 7 required' }
$taskRoot = 'C:/Users/mysti/AppData/Local/Temp/sndb338-validation-20260908'
$timer = [Diagnostics.Stopwatch]::StartNew()
$identityFiles = @(Get-ChildItem -LiteralPath $taskRoot -Filter '*.log.process.json' -File)
if ($identityFiles.Count -gt 64) { throw 'Identity record budget exceeded' }
if ($Trial) { $identityFiles = @($identityFiles | Select-Object -First 1) }
$identities = @()
foreach ($file in $identityFiles) {
    if ($timer.Elapsed.TotalSeconds -ge 15) { throw 'Identity read timeout' }
    $identities += Get-Content -LiteralPath $file.FullName -Raw | ConvertFrom-Json
}
$running = @(Get-CimInstance Win32_Process -Filter "Name = 'dotnet.exe' OR Name = 'testhost.exe' OR Name = 'SonnetDB.CrashTests.Child.exe'")
if ($running.Count -gt 256 -or $timer.Elapsed.TotalSeconds -ge 30) { throw 'Process inventory budget exceeded' }
$activeRoots = @()
foreach ($identity in $identities) {
    if ($timer.Elapsed.TotalSeconds -ge 45) { throw 'Identity matching timeout' }
    $match = @($running | Where-Object {
        $_.ProcessId -eq $identity.ProcessId -and $_.ParentProcessId -eq $identity.ParentProcessId -and
        $_.CommandLine -eq $identity.CommandLine -and
        $_.CreationDate.ToUniversalTime() -eq ([DateTime]$identity.CreationDate).ToUniversalTime()
    })
    $activeRoots += $match
}
$candidates = @($running | Where-Object {
    $_.CommandLine -match 'SonnetDB\.(Core\.Tests|Tests|CrashTests)' -and
    $_.CreationDate -ge [DateTime]'2026-09-08T08:00:00'
} | Select-Object ProcessId,ParentProcessId,CreationDate,CommandLine)
$result = [ordered]@{
    checkedAt = [DateTimeOffset]::Now.ToString('O')
    recordedRoots = $identities.Count
    activeOwnedRoots = @($activeRoots | Select-Object ProcessId,ParentProcessId,CreationDate,CommandLine)
    remainingTestProcessCandidates = $candidates
    action = 'Read-only identity check; no process terminated by name or unknown ownership.'
}
if ($Trial) { $result | ConvertTo-Json -Depth 6; exit 0 }
$result | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $taskRoot 'process-cleanup.json')
$result | ConvertTo-Json -Depth 6
if ($activeRoots.Count -ne 0 -or $candidates.Count -ne 0) { throw 'Process cleanup requires ownership review before archival' }
